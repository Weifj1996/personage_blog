﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","gl",{title:"Propiedades do marcador de posición",toolbar:"Crear un marcador de posición",name:"Nome do marcador de posición",invalidName:"O marcador de posición non pode estar baleiro e non pode conter ningún dos caracteres seguintes: [, ], <, >",pathName:"marcador de posición"});